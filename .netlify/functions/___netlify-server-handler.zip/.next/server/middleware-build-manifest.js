globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/d415f3b813bfd931.js",
      "static/chunks/turbopack-fa8ade13f1139499.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/d415f3b813bfd931.js",
      "static/chunks/turbopack-f7989ed74c93b0d8.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/94bfed6bcc83c30d.js",
    "static/chunks/91adb7bdb9870c6a.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/c19da6693934fea1.js",
    "static/chunks/2008ffcf9e5b170c.js",
    "static/chunks/turbopack-e7150bd6a6069435.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];
var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/delete-result/route.js")
R.c("server/chunks/[root-of-the-server]__f1955c7f._.js")
R.c("server/chunks/[root-of-the-server]__46d8ec2e._.js")
R.m(22266)
R.m(64143)
module.exports=R.m(64143).exports

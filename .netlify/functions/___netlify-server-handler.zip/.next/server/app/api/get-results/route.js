var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/get-results/route.js")
R.c("server/chunks/[root-of-the-server]__db736330._.js")
R.c("server/chunks/[root-of-the-server]__46d8ec2e._.js")
R.m(5776)
R.m(27553)
module.exports=R.m(27553).exports

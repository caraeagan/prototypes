var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/submit-test/route.js")
R.c("server/chunks/[root-of-the-server]__35f4ad4d._.js")
R.c("server/chunks/[root-of-the-server]__46d8ec2e._.js")
R.m(4719)
R.m(582)
module.exports=R.m(582).exports
